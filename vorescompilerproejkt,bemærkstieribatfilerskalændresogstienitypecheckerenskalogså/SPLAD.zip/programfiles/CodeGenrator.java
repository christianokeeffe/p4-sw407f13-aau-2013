import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class CodeGenrator extends SPLADBaseVisitor<Value>{
	
	@Override
	public Value visitAssign(SPLADParser.AssignContext ctx) {
		if(ctx.assignend() != null){
			visit(ctx.callid());
			visit(ctx.assignend());
		}
		return null;
	}
	
	@Override
	public Value visitTermsymbol(SPLADParser.TermsymbolContext ctx){
		if (ctx.getText().trim().equals("AND")){
			System.out.print("&&");
		}
		else {
		System.out.print(ctx.getText());
		}
		return null;
	}
	
	@Override
	public Value visitExprsymbol(SPLADParser.ExprsymbolContext ctx){
		if (ctx.getText().trim().equals("OR")){
			System.out.print("||");
		}
		else {
		System.out.print(ctx.getText());
		}
		return null;
	}
	
	@Override
	public Value visitNumeric(SPLADParser.NumericContext ctx) {
		visit(ctx.plusminus());
		System.out.print(ctx.DIGIT().getText());
		visit(ctx.numericend());
		return null;
	}
	
	@Override
	public Value visitNontermswitch(SPLADParser.NontermswitchContext ctx) {
		System.out.print("switch(");
		visit(ctx.expr());
		System.out.print(")\n{\n");
		visit(ctx.cases());
		System.out.print("}\n");
		return null;
	}
	
	@Override
	public Value visitRoot(SPLADParser.RootContext ctx) {
		if(ctx.dcl() != null){
			visit(ctx.dcl());
			System.out.print(";\n");
		}
		else if (ctx.function() != null){
			visit(ctx.function());
		}
		else if (ctx.assign() != null)
		{
			visit(ctx.assign());
			System.out.print(";\n");
		}
		return null;
	}
	
	@Override
	public Value visitNontermwhile(SPLADParser.NontermwhileContext ctx) {
		System.out.print("while (");
		visit(ctx.expr());
		System.out.print(")\n");
		System.out.print("{\n");
		visit(ctx.stmts());
		System.out.print("}\n");
		return null;
	}
	
	@Override
	public Value visitStmts(SPLADParser.StmtsContext ctx) {
		if (ctx.stmt() != null){
			visit(ctx.stmt());
			visit(ctx.stmts());
		}
		return null;
	}
	
	@Override
	public Value visitTermend(SPLADParser.TermendContext ctx) {
		if (ctx.getText() != ""){
			visit(ctx.termsymbol());
			visit(ctx.term());
		}
		return null;
	}
	
	@Override
	public Value visitNumericend(SPLADParser.NumericendContext ctx) {
		if (ctx.getText() != ""){
			System.out.print("." + ctx.DIGIT().getText());
		}
		return null;
	}
	
	@Override
	public Value visitExpr(SPLADParser.ExprContext ctx) {
		visit(ctx.term());
		visit(ctx.exprend());
		return null;
	}
	
	@Override
	public Value visitFrom(SPLADParser.FromContext ctx) {
		System.out.print("for(");
		visit(ctx.assign());
		System.out.print("; ");
		visit(ctx.assign().callid());
		System.out.print("<=");
		visit(ctx.expr());
		System.out.print("; ");
		visit(ctx.assign().callid());
		System.out.print("= ");
		visit(ctx.assign().callid());
		System.out.print(" + ");
		visit(ctx.plusminus());
		System.out.print(ctx.DIGIT().getText());
		System.out.print(")\n{\n");
		visit(ctx.stmts());
		System.out.print("}\n");
		return null;
	}
	
	@Override
	public Value visitCallexpr(SPLADParser.CallexprContext ctx) {
		if (ctx.subcallexpr() != null){
			visit(ctx.subcallexpr());
		}
		return null;
	}
	
	@Override
	public Value visitType(SPLADParser.TypeContext ctx) {
		visit(ctx.primitivetype());
		visit(ctx.arraytype());
		return null;
	}
	
	@Override
	public Value visitPrimitivetype(SPLADParser.PrimitivetypeContext ctx){
		if (ctx.getText().trim().equals("string")){
			System.out.print("String");
		}
		else {
			System.out.print(ctx.getText());
		}
		return null;
	}
	
	@Override
	public Value visitFunction(SPLADParser.FunctionContext ctx) {
		if (ctx.functionmidt().type() != null){
		visit(ctx.functionmidt().type());
		}
		else {
			System.out.print("void ");
		}
		visit(ctx.id());
		visit(ctx.functionmidt());
		return null;
	}
	
	@Override
	public Value visitId(SPLADParser.IdContext ctx) {
		System.out.print(ctx.getText() + " ");
		return null;
	}
	
	@Override
	public Value visitFunctioncall(SPLADParser.FunctioncallContext ctx) {
		visit(ctx.id());
		System.out.print("(");
		visit(ctx.callexpr());
		System.out.print(")");
		return null;
	}
	
	@Override
	public Value visitEndif(SPLADParser.EndifContext ctx) {
		if (ctx.nontermelse() != null){
			System.out.print("else\n");
			visit(ctx.nontermelse());
		}
		return null;
	}
	
	@Override
	public Value visitArraytype(SPLADParser.ArraytypeContext ctx) {
		System.out.print(ctx.getText() + " ");
		return null;
	}
	
	@Override
	public Value visitSubcallexprend(SPLADParser.SubcallexprendContext ctx) {
		if (ctx.subcallexpr() != null){
			System.out.print(", ");
			visit(ctx.subcallexpr());
		}
		return null;
	}
	
	@Override
	public Value visitSubparamsend(SPLADParser.SubparamsendContext ctx) {
		if (ctx.subparams() != null){
			System.out.print(", ");
			visit(ctx.subparams());
		}
		return null;
	}
	
	@Override
	public Value visitNontermif(SPLADParser.NontermifContext ctx) {
		System.out.print("if (");
		visit(ctx.expr());
		System.out.print(")\n{\n");
		visit(ctx.stmts());
		System.out.print("}\n");
		visit(ctx.endif());
		return null;
	}
	
	@Override
	public Value visitAssignend(SPLADParser.AssignendContext ctx) {
		System.out.print("= ");
		visit(ctx.expr());
		return null;
	}
	
	@Override
	public Value visitComparisonoperator(SPLADParser.ComparisonoperatorContext ctx) {
		switch (ctx.getText().trim()){
		case "=":
			System.out.print("==");
			break;
		default:
			System.out.print(ctx.getText());
			break;
		}
		
		return null;
	}
	
	@Override
	public Value visitExprend(SPLADParser.ExprendContext ctx) {
		if (ctx.getText() != ""){
		visit(ctx.exprsymbol());
		visit(ctx.expr());
		}
		return null;
	}
	
	@Override
	public Value visitComp(SPLADParser.CompContext ctx) {
		visit(ctx.factor());
		visit(ctx.compend());
		return null;
	}
	
	@Override
	public Value visitCases(SPLADParser.CasesContext ctx) {
		System.out.print("case ");
		visit(ctx.expr());
		System.out.print(":\n");
		visit(ctx.stmts());
		visit(ctx.endcase());
		return null;
	}
	
	@Override
	public Value visitNontermelse(SPLADParser.NontermelseContext ctx) {
		if (ctx.nontermif() != null){
			visit(ctx.nontermif());
		}
		else {
			System.out.print("{\n");
			visit(ctx.stmts());
			System.out.print("}\n");
		}
		return null;
	}
	
	@Override
	public Value visitRoots(SPLADParser.RootsContext ctx) {
		if (ctx.root() != null){
			visit(ctx.root());
			visit(ctx.roots());
		}
		return null;
	}
	
	@Override
	public Value visitStmt(SPLADParser.StmtContext ctx) {
		if (ctx.assign() != null){
			visit(ctx.assign());
			System.out.print(";\n");
		}
		else if (ctx.nontermif() != null){
			visit(ctx.nontermif());
		}
		else if (ctx.nontermwhile() != null){
			visit(ctx.nontermwhile());
		}
		else if (ctx.from() != null){
			visit(ctx.from());
		}
		else if (ctx.dcl() != null){
			visit(ctx.dcl());
			System.out.print(";\n");
		}
		else if (ctx.functioncall() != null){
			visit(ctx.functioncall());
			System.out.print(";\n");
		}
		else if (ctx.nontermswitch() != null){
			visit(ctx.nontermswitch());
		}
		else if (ctx.COMMENT() != null){
			System.out.print(ctx.COMMENT().getText() + " ");
		}
		return null;
	}
	
	@Override
	public Value visitSubcallexpr(SPLADParser.SubcallexprContext ctx) {
		visit(ctx.expr());
		visit(ctx.subcallexprend());
		return null;
	}
	
	@Override
	public Value visitParams(SPLADParser.ParamsContext ctx) {
		if (ctx.subparams() != null){
			visit(ctx.subparams());
		}
		return null;
	}
	
	@Override
	public Value visitFactor(SPLADParser.FactorContext ctx) {
		if(ctx.cast() != null){
			visit(ctx.cast());
		}
		else if(ctx.string() != null){
			visit(ctx.string());
		}
		else if(ctx.functioncall() != null){
			visit(ctx.functioncall());
		}
		else if(ctx.numeric() != null){
			visit(ctx.numeric());
		}
		else if(ctx.callid() != null){
			visit(ctx.callid());
		}
		else {
			String[] splitarray = ctx.getText().trim().split(" ");
			if (splitarray[0].equals("LOW")){
				System.out.print("LOW");
			}
			else if (splitarray[0].equals("HIGH")){
				System.out.print("HIGH");
			}
			else if (splitarray[0].equals("true")){
				System.out.print("true");
			}
			else if (splitarray[0].equals("false")){
				System.out.print("false");
			}
			else if (splitarray[0].toCharArray()[0] == '!'){
				System.out.print("!(");
				visit(ctx.expr());
				System.out.print(")");
			}
			else if (splitarray[0].toCharArray()[0] == '('){
				System.out.print("(");
				visit(ctx.expr());
				System.out.print(")");
			}
			
		}
		return null;
	}
	
	@Override
	public Value visitFunctionmidt(SPLADParser.FunctionmidtContext ctx) {
		if (ctx.type() != null){
			visit(ctx.functionend());
			visit(ctx.expr());
			System.out.print(";\n}");
		}
		else {
			visit(ctx.functionend());
			System.out.print(";\n}\n");
		}
		return null;
	}
	
	@Override
	public Value visitDcl(SPLADParser.DclContext ctx) {
		visit(ctx.type());
		visit(ctx.assign());
		return null;
	}
	
	@Override
	public Value visitArrayiden(SPLADParser.ArrayidenContext ctx) {
		if(ctx != null){
			System.out.print(ctx.getText() + " ");
		}
		return null;
	}
	
	@Override
	public Value visitSubparams(SPLADParser.SubparamsContext ctx) {
		visit(ctx.type());
		visit(ctx.id());
		visit(ctx.subparamsend());
		return null;
	}
	
	@Override
	public Value visitPlusminus(SPLADParser.PlusminusContext ctx) {
		System.out.print(ctx.getText() + " ");
		return null;
	}
	
	@Override
	public Value visitCast(SPLADParser.CastContext ctx) {
		System.out.print("(");
		visit(ctx.type());
		System.out.print(") ");
		visit(ctx.expr());
		return null;
	}
	
	@Override
	public Value visitEndcase(SPLADParser.EndcaseContext ctx) {
		if (ctx.cases() != null){
			visit(ctx.cases());
		}
		else if (ctx.breakend() != null){
			System.out.print("break;\n");
			visit(ctx.breakend());
		}
		else {
			System.out.print("default:\n");
			visit(ctx.stmts());
			System.out.print("break;\n");
		}
		return null;
	}
	
	@Override
	public Value visitTerm(SPLADParser.TermContext ctx) {
		visit(ctx.comp());
		visit(ctx.termend());
		return null;
	}
	
	@Override
	public Value visitCallid(SPLADParser.CallidContext ctx) {
		visit(ctx.id());
		visit(ctx.arrayiden());
		return null;
	}
	
	@Override
	public Value visitProgram(SPLADParser.ProgramContext ctx) {
		PrintContentofFile("C:\\test\\header.txt");
		visit(ctx.roots());
		return null;
	}
	
	@Override
	public Value visitString(SPLADParser.StringContext ctx) {
		System.out.print(ctx.getText());
		return null;
	}
	
	@Override
	public Value visitFunctionend(SPLADParser.FunctionendContext ctx) {
		System.out.print("(");
		visit(ctx.params());
		System.out.print(")\n{\n");
		if(((SPLADParser.FunctionContext)ctx.parent.parent).id().getText().equals("setup")){
			PrintContentofFile("C:\\test\\setup.txt");
		}
		visit(ctx.stmts());
		System.out.print("return ");
		return null;
	}
	
	@Override
	public Value visitBreakend(SPLADParser.BreakendContext ctx) {
		if (ctx.cases() != null){
			visit(ctx.cases());
		}
		else if (ctx.stmts() != null){
			System.out.print("default:\n");
			visit(ctx.stmts());
			System.out.print("break;\n");
		}
		return null;
	}
	
	@Override
	public Value visitCompend(SPLADParser.CompendContext ctx) {
		if(ctx.getText() != ""){
			visit(ctx.comparisonoperator());
			visit(ctx.comp());
		}
		return null;
	}
	
	private void PrintContentofFile(String path){
		BufferedReader in;
		try{
			in = new BufferedReader(new FileReader(path));
			while (in.ready()){
				String fileintxt = in.readLine();
				System.out.print(fileintxt+"\n");
			}
			in.close();
		}
		catch (FileNotFoundException error){
			/*file not found do something*/
		}
		catch (IOException IOerror){
			/*some error do something*/
		}
	}
}
